package application;

import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class AsteroidAdventureApp extends Application {

    @Override
    public void start(Stage primaryStage) {


        showMainScreen(primaryStage);

    }

    public static void showMainScreen(Stage primaryStage) {
        primaryStage.setTitle("Asteroid Adventure");


        GridPane gridPane = new GridPane();
        gridPane.setBackground(new Background(new BackgroundFill(Color.BLACK, null, null)));
        gridPane.setPadding(new Insets(20));
        gridPane.setVgap(10);

        ColumnConstraints colConstraints = new ColumnConstraints();
        colConstraints.setPercentWidth(100 / 3.0);
        gridPane.getColumnConstraints().addAll(colConstraints, colConstraints, colConstraints);

        Label label1 = new Label("Welcome to");
        Label label2 = new Label("Asteroid Adventure");
        Label label3 = new Label("by");
        label1.setTextFill(Color.WHITE);
        label2.setTextFill(Color.WHITE);
        label2.setStyle("-fx-font-size: 24px;");
        label3.setTextFill(Color.WHITE);
        label3.setStyle("-fx-font-size: 12px;");

        Button tutorialButton = createStyledButton("Tutorial", Color.BLUE);
        tutorialButton.setOnAction(event -> {
                    TutorialScene.createTutorialScene(primaryStage);

                }
        );


        Button settingsButton = createStyledButton("Change Settings", Color.GREEN);
        settingsButton.setOnAction(event -> {
                    SettingsScene.createSettingsScene(primaryStage);
                }
        );


        Button loadButton = createStyledButton("Load Save Game", Color.PURPLE);
        loadButton.setOnAction(event -> {
                    LoadGameScene.createLoadGameScene(primaryStage);
                }
        );


        Button playButton = createStyledButton("Play Game", Color.RED);
        playButton.setOnAction(event -> {
                    GameScene.createGameScene(primaryStage, SettingsScene.MapSize, SettingsScene.NumOfMissiles, SettingsScene.NumOfBoosters, SettingsScene.NumOfPirates, SettingsScene.NumOfAsteroids, SettingsScene.NumOfTreasures);
                }
        );


        GridPane.setHalignment(label1, HPos.CENTER);
        GridPane.setHalignment(label2, HPos.CENTER);
        GridPane.setHalignment(label3, HPos.CENTER);
        GridPane.setHalignment(tutorialButton, HPos.CENTER);
        GridPane.setHalignment(settingsButton, HPos.CENTER);
        GridPane.setHalignment(loadButton, HPos.CENTER);
        GridPane.setHalignment(playButton, HPos.CENTER);

        gridPane.add(label1, 1, 0);
        gridPane.add(label2, 1, 1);
        gridPane.add(label3, 1, 2);
        gridPane.add(tutorialButton, 1, 3);
        gridPane.add(settingsButton, 1, 4);
        gridPane.add(loadButton, 1, 5);
        gridPane.add(playButton, 1, 6);


        gridPane.setAlignment(Pos.CENTER);

        Scene scene = new Scene(gridPane, 950, 700);
        primaryStage.setScene(scene);


        TranslateTransition slideIn = new TranslateTransition(Duration.seconds(2), gridPane);
        gridPane.setTranslateY(-scene.getHeight());
        slideIn.setToY(0);

        slideIn.play();
        primaryStage.setOnShown(event -> {
            gridPane.setTranslateY(0);
        });

        primaryStage.show();
    }

    private static Button createStyledButton(String text, Color textColor) {
        Button button = new Button(text);
        button.setTextFill(textColor);
        button.setCursor(Cursor.HAND);
        button.setStyle("-fx-font-size: 14px;");
        return button;
    }

    public static void main(String[] args) {
        launch();
    }
}
