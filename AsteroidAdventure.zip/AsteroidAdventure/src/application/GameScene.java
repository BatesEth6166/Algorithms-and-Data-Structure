package application;

import javafx.animation.TranslateTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import java.util.*;

public class GameScene {

    private static int turnsUsed;
    private static int missilesRemaining;
    private static int boostersRemaining;
    private static Button upButton;
    private static Button downButton;
    private static Button leftButton;
    private static Button rightButton;
    private static Button missileButton;
    private static Button boostButton;
    private static int shipRowPos;
    private static int shipColPos;
    private static int exitRowPos;
    private static int exitColPos;
    private static Type[][] typesArray;
    private static GridPane gameBoard;
    private static BoardCell shipCell;

    private static int treasuresCollected;
    private static boolean isMissileClicked;
    
    private static Label turnsLabel;
    private static Label boostersLabel;
    private static Label missilesLabel;
    private static boolean isBoostClicked;
    private static GridPane gamePane;
    private static Stage primeStage;
    private static List<BoardCell> pirateShips;
    private static BoardCell exitCell;

    private static int mapSize;
    private static int numOfPirates;
    private static int numOfAsteroids;
    private static int numOfTreasures;


    public static void loadGameScene(Stage primaryStage, GameState gameState) {
        primeStage = primaryStage;
        turnsUsed = gameState.getTurnsUsed();
        mapSize = gameState.getBoardSize();
        numOfPirates = gameState.getPiratePositions().size();
        missilesRemaining = gameState.getMissilesRemaining();
        boostersRemaining = gameState.getBoostersRemaining();
        numOfAsteroids = gameState.getAsteroidPositions().size();
        numOfTreasures = gameState.getTreasurePositions().size();
        treasuresCollected = gameState.getTreasuresCollected();
        isMissileClicked = false;
        isBoostClicked = false;

        
        pirateShips = new ArrayList();
        gamePane = new GridPane();
        gamePane.setBackground(new Background(new BackgroundFill(Color.BLACK, null, null)));
        gamePane.setPadding(new Insets(20));
        gamePane.setVgap(10);
        gamePane.setHgap(20);

        gameBoard = loadGameBoard(gameState);
        GridPane controlPanel = createControlPanel();
        GridPane saveBackButtonsPane = createSaveBackButtonPane(primaryStage, gamePane);
        GridPane labelPane = createLabelPane();

        gamePane.add(gameBoard, 0, 0);
        gamePane.add(controlPanel, 2, 0);
        gamePane.add(saveBackButtonsPane, 0, 1);
        gamePane.add(labelPane, 0, 2);

        gamePane.setAlignment(Pos.CENTER);

        Scene gameScene = new Scene(gamePane, 950, 700);

        TranslateTransition gameTransition = new TranslateTransition(Duration.seconds(2), gamePane);
        gameTransition.setFromY(-gamePane.getHeight());
        gameTransition.setToY(0);
        gameTransition.play();
        primaryStage.setScene(gameScene);
        gameTransition.play();

    }

    private static GridPane loadGameBoard(GameState gameState) {
        GridPane gameBoard = new GridPane();
        gameBoard.setBorder(new Border(new BorderStroke(
                Color.WHITE,
                BorderStrokeStyle.SOLID,
                null,
                new BorderWidths(1)
        )));

        typesArray = new Type[mapSize][mapSize];

        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                typesArray[i][j] = Type.Blank;

            }
        }

        String[] shipPosition = gameState.getShipPosition().split(",");
        int shipRow = Integer.parseInt(shipPosition[0]);
        int shipCol = Integer.parseInt(shipPosition[1]);
        typesArray[shipRow][shipCol] = Type.Ship;

        String[] exitPosition = gameState.getExitPosition().split(",");
        int exitRow = Integer.parseInt(exitPosition[0]);
        int exitCol = Integer.parseInt(exitPosition[1]);
        typesArray[exitRow][exitCol] = Type.Exit;


        List<String> asteroidPositions = gameState.getAsteroidPositions();
        for (String asteroidPos : asteroidPositions) {
            String[] pos = asteroidPos.split(",");
            int astRow = Integer.parseInt(pos[0]);
            int astCol = Integer.parseInt(pos[1]);
            typesArray[astRow][astCol] = Type.Asteroid;
        }


        List<String> piratePositions = gameState.getPiratePositions();
        for (String piratePos : piratePositions) {
            String[] pos = piratePos.split(",");
            int pirateRow = Integer.parseInt(pos[0]);
            int pirateCol = Integer.parseInt(pos[1]);
            typesArray[pirateRow][pirateCol] = Type.Pirate;
        }


        List<String> treasurePositions = gameState.getTreasurePositions();
        for (String treasurePos : treasurePositions) {
            String[] pos = treasurePos.split(",");
            int treasureRow = Integer.parseInt(pos[0]);
            int treasureCol = Integer.parseInt(pos[1]);
            typesArray[treasureRow][treasureCol] = Type.Treasure;
        }


        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                BoardCell boardCell = new BoardCell(typesArray[i][j]);
                boardCell.setTextFill(Color.WHITE);
                boardCell.setStyle(mapSize);
                boardCell.setCursor(Cursor.HAND);

                if (typesArray[i][j] == Type.Ship) {
                    shipCell = boardCell;
                } else if (typesArray[i][j] == Type.Pirate) {
                    pirateShips.add(boardCell);
                } else if (typesArray[i][j] == Type.Exit) {
                    exitCell = boardCell;
                }


                gameBoard.add(boardCell, j, i);
            }
        }


        return gameBoard;
    }


    public static void createGameScene(Stage primaryStage, int mapSize1, int missilesRemain, int boostersRemain, int pirates, int asteroids, int treasures) {
        primeStage = primaryStage;
        turnsUsed = 0;
        mapSize = mapSize1;
        numOfPirates = pirates;
        missilesRemaining = missilesRemain;
        boostersRemaining = boostersRemain;
        numOfAsteroids = asteroids;
        numOfTreasures = treasures;
        treasuresCollected = 0;
        isMissileClicked = false;
        isBoostClicked = false;
        pirateShips = new ArrayList();
        gamePane = new GridPane();
        gamePane.setBackground(new Background(new BackgroundFill(Color.BLACK, null, null)));
        gamePane.setPadding(new Insets(20));
        gamePane.setVgap(10);
        gamePane.setHgap(10);

        gameBoard = createGameBoard();
        GridPane controlPanel = createControlPanel();
        GridPane saveBackButtonsPane = createSaveBackButtonPane(primaryStage, gamePane);
        GridPane labelPane = createLabelPane();

        gamePane.add(gameBoard, 0, 0);
        gamePane.add(controlPanel, 2, 0);
        gamePane.add(saveBackButtonsPane, 0, 1);
        gamePane.add(labelPane, 0, 2);

        gamePane.setAlignment(Pos.CENTER);

        Scene gameScene = new Scene(gamePane, 950, 700);

        TranslateTransition gameTransition = new TranslateTransition(Duration.seconds(2), gamePane);
        gameTransition.setFromY(-gamePane.getHeight());
        gameTransition.setToY(0);
        gameTransition.play();
        primaryStage.setScene(gameScene);
        gameTransition.play();

    }

    private static GridPane createLabelPane() {
        GridPane labelPane = new GridPane();
        labelPane.setAlignment(Pos.CENTER);

        turnsLabel = createStyledLabel("Turns: " + turnsUsed);
        missilesLabel = createStyledLabel("Missiles: " + missilesRemaining);
        boostersLabel = createStyledLabel("Boosters: " + boostersRemaining);

        labelPane.add(turnsLabel, 0, 0);
        labelPane.add(missilesLabel, 0, 1);
        labelPane.add(boostersLabel, 0, 2);

        return labelPane;
    }


    private static GridPane createSaveBackButtonPane(Stage primaryStage, GridPane gamePane) {
        GridPane saveBackButtonsPane = new GridPane();
        saveBackButtonsPane.setHgap(20);
        saveBackButtonsPane.setAlignment(Pos.CENTER);

        Button saveButton = new Button("Save Game");
        saveButton.setStyle("-fx-font-size: 14px;");
        saveButton.setCursor(Cursor.HAND);
        saveButton.setOnAction(event -> {

            saveClicked();
        });


        Button backButton = new Button("Back to Menu");
        backButton.setStyle("-fx-font-size: 14px;");
        backButton.setCursor(Cursor.HAND);
        backButton.setOnAction(event -> {
            gamePane.setTranslateX(0);
            gamePane.setTranslateY(0);
            AsteroidAdventureApp.showMainScreen(primaryStage);

        });


        saveBackButtonsPane.add(saveButton, 0, 1);
        saveBackButtonsPane.add(backButton, 1, 1);
        return saveBackButtonsPane;
    }

    private static void saveClicked() {

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Save Game");
        dialog.setHeaderText("Enter a file name to save the game:");
        dialog.setContentText("File Name:");

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(fileName -> {


            GameState gameState = new GameState();

            gameState.setBoardSize(mapSize);
            gameState.setTurnsUsed(turnsUsed);
            gameState.setMissilesRemaining(missilesRemaining);
            gameState.setBoostersRemaining(boostersRemaining);
            gameState.setTreasuresCollected(treasuresCollected);

            gameState.setShipPosition(GridPane.getRowIndex(shipCell) + "," + GridPane.getColumnIndex(shipCell));
            gameState.setExitPosition(GridPane.getRowIndex(exitCell) + "," + GridPane.getColumnIndex(exitCell));


            List<String> piratePositions = new ArrayList<>();
            List<String> asteroidPositions = new ArrayList<>();
            List<String> treasurePositions = new ArrayList<>();
            for (Node node : gameBoard.getChildren()) {
                BoardCell cell = (BoardCell) node;
                int row = GridPane.getRowIndex(cell);
                int col = GridPane.getColumnIndex(cell);
                if (cell.getType() == Type.Asteroid) {
                    asteroidPositions.add(row + "," + col);
                } else if (cell.getType() == Type.Pirate) {
                    piratePositions.add(row + "," + col);
                } else if (cell.getType() == Type.Treasure) {
                    treasurePositions.add(row + "," + col);
                }

            }
            gameState.setPiratePositions(piratePositions);
            gameState.setAsteroidPositions(asteroidPositions);
            gameState.setTreasurePositions(treasurePositions);

            gameState.setSavedDate(new Date());
            saveGameStateToFile(gameState, fileName);
        });
    }

    private static void saveGameStateToFile(GameState gameState, String fileName) {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("saved_games/" + fileName + ".dat"))) {
            outputStream.writeObject(gameState);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Game saved successfully");

        } catch (IOException e) {

            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Error saving game");
        }
    }

    private static void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    private static GridPane createControlPanel() {
        GridPane controlPanel = new GridPane();
        controlPanel.setPadding(new Insets(20));
        controlPanel.setVgap(10);

        upButton = createStyledButton("Up");
        upButton.setOnAction(event -> {
            upButtonClicked(1);
            turnsUsed++;
            turnsLabel.setText("Turns: " + turnsUsed);


        });

        downButton = createStyledButton("Down");
        downButton.setOnAction(event -> {
            downButtonClicked(1);
            turnsUsed++;
            turnsLabel.setText("Turns: " + turnsUsed);

        });


        leftButton = createStyledButton("Left");
        leftButton.setOnAction(event -> {
            leftButtonClicked(1);
            turnsUsed++;
            turnsLabel.setText("Turns: " + turnsUsed);

        });


        rightButton = createStyledButton("Right");
        rightButton.setOnAction(event -> {
            rightButtonClicked(1);
            turnsUsed++;
            turnsLabel.setText("Turns: " + turnsUsed);

        });


        missileButton = createStyledButton("Missile");
        missileButton.setOnAction(event -> {
            missileButtonClicked();

        });


        boostButton = createStyledButton("Boost");
        boostButton.setOnAction(event -> {
            boostButtonClicked();

        });


        controlPanel.add(upButton, 0, 0);
        controlPanel.add(downButton, 0, 1);
        controlPanel.add(leftButton, 0, 2);
        controlPanel.add(rightButton, 0, 3);
        controlPanel.add(missileButton, 0, 4);
        controlPanel.add(boostButton, 0, 5);

        return controlPanel;
    }

    private static void movePirateShips() {
        int shipRow = GridPane.getRowIndex(shipCell);
        int shipCol = GridPane.getColumnIndex(shipCell);

        for (BoardCell pirateShip : pirateShips) {
            int pirateRow = GridPane.getRowIndex(pirateShip);
            int pirateCol = GridPane.getColumnIndex(pirateShip);
            List<BoardCell> path = findPathToShipUsingDFS(pirateRow, pirateCol, shipRow, shipCol);


            if (!path.isEmpty() && path.size() >= 2) {
                BoardCell replaceCell = path.get(1);

                int replaceRow = GridPane.getRowIndex(replaceCell);
                int replaceCol = GridPane.getColumnIndex(replaceCell);

                if (replaceCell.getType() == Type.Blank) {
                    animateMove(pirateShip, replaceCell, pirateRow, pirateCol, replaceRow, replaceCol, false, false);

                } else if (replaceCell.getType() == Type.Treasure) {

                    animateMove(pirateShip, replaceCell, pirateRow, pirateCol, replaceRow, replaceCol, true, false);

                } else if (replaceCell.getType() == Type.Ship) {

                    animateMove(pirateShip, replaceCell, pirateRow, pirateCol, replaceRow, replaceCol, true, true);

                }
            }
        }
    }

    private static List<BoardCell> findPathToShipUsingDFS(int startRow, int startCol, int targetRow, int targetCol) {
        List<BoardCell> path = new ArrayList<>();
        boolean[][] visited = new boolean[mapSize][mapSize];
        Stack<BoardCell> stack = new Stack<>();

        stack.push(getReplaceCell(startRow, startCol));
        visited[startRow][startCol] = true;

        while (!stack.isEmpty()) {
            BoardCell currentCell = stack.pop();
            int currentRow = GridPane.getRowIndex(currentCell);
            int currentCol = GridPane.getColumnIndex(currentCell);

            if (currentRow == targetRow && currentCol == targetCol) {

                while (currentCell != null) {
                    path.add(0, currentCell);
                    currentCell = currentCell.getPreviousCell();

                }
                break;
            }

            List<BoardCell> neighbors = new ArrayList<>();

            neighbors.add(getReplaceCell(currentRow - 1, currentCol));
            neighbors.add(getReplaceCell(currentRow + 1, currentCol));
            neighbors.add(getReplaceCell(currentRow, currentCol - 1));
            neighbors.add(getReplaceCell(currentRow, currentCol + 1));

            neighbors.removeIf(Objects::isNull);
            neighbors.sort(Comparator.comparingInt(neighbor ->
                    distance(GridPane.getRowIndex(neighbor), GridPane.getColumnIndex(neighbor), targetRow, targetCol)
            ));


            for (BoardCell neighbor : neighbors) {
                int neighborRow = GridPane.getRowIndex(neighbor);
                int neighborCol = GridPane.getColumnIndex(neighbor);


                if (neighborRow >= 0 && neighborRow < mapSize && neighborCol >= 0 && neighborCol < mapSize && !visited[neighborRow][neighborCol]) {

                    if (neighbor.getType() != Type.Asteroid && neighbor.getType() != Type.Pirate && neighbor.getType() != Type.Exit) {
                        stack.push(neighbor);
                        visited[neighborRow][neighborCol] = true;
                        neighbor.setPreviousCell(currentCell);
                        break;
                    }
                }

            }


        }

        return path;
    }


    private static BoardCell getReplaceCell(int row, int col) {
        BoardCell replaceCell = null;
        BoardCell cell;
        int idx = 0;
        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                cell = (BoardCell) gameBoard.getChildren().get(idx);
                if (GridPane.getRowIndex(cell) == row && GridPane.getColumnIndex(cell) == col) {
                    replaceCell = cell;
                    break;
                }
                idx++;
            }
        }
        return replaceCell;
    }


    private static void showGameOver(boolean isWin) {
        gamePane.setTranslateX(0);
        gamePane.setTranslateY(0);
        GameOverScene.createGameOverScene(primeStage, isWin, turnsUsed, treasuresCollected);

    }

    private static void boostButtonClicked() {
        isBoostClicked = true;
        boostersRemaining--;
        if (boostersRemaining >= 0) {
            boostersLabel.setText("Boosters: " + boostersRemaining);
        }
    }

    private static void missileButtonClicked() {
        isMissileClicked = true;
        missilesRemaining--;
        if (missilesRemaining >= 0)
            missilesLabel.setText("Missiles: " + missilesRemaining);
    }


    private static void rightButtonClicked(int cols) {
        int shipRow = GridPane.getRowIndex(shipCell);
        int shipCol = GridPane.getColumnIndex(shipCell);

        boolean destroyed = false;

        if (isBoostClicked) {
            if (boostersRemaining >= 0) {

                int replaceCol1 = shipCol + 1;
                int replaceCol2 = shipCol + 2;
                int replaceCol3 = shipCol + 3;

                BoardCell replaceCell1 = getReplaceCell(shipRow, replaceCol1);
                BoardCell replaceCell2 = getReplaceCell(shipRow, replaceCol2);
                BoardCell replaceCell3 = getReplaceCell(shipRow, replaceCol3);

                if (replaceCell1 == null || replaceCell1.getType() == Type.Asteroid) {
                    isBoostClicked = false;
                    return;
                } else if (replaceCell2 == null || replaceCell2.getType() == Type.Asteroid) {
                    if (replaceCell1.getType() != Type.Pirate) {
                        isBoostClicked = false;
                        rightButtonClicked(1);
                    }
                    return;
                } else if (replaceCell3 == null || replaceCell3.getType() == Type.Asteroid) {
                    if (replaceCell1.getType() != Type.Pirate) {
                        isBoostClicked = false;
                        rightButtonClicked(1);
                    }
                    if (replaceCell2.getType() != Type.Pirate) {
                        rightButtonClicked(1);
                    }
                    return;
                } else if (replaceCell3.getType() == Type.Blank || replaceCell3.getType() == Type.Treasure) {
                    isBoostClicked = false;
                    rightButtonClicked(3);
                    return;
                }

            }

            isBoostClicked = false;
        } else if (isMissileClicked) {
            if (missilesRemaining >= 0) {
                int idx = 1;
                while (!destroyed) {
                    int targetCol = shipCol + idx;
                    idx++;

                    if (targetCol < mapSize) {
                        BoardCell targetCell = getReplaceCell(shipRow, targetCol);

                        if (targetCell.getType() == Type.Asteroid) {
                            
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        } else if (targetCell.getType() == Type.Pirate) {
                            
                            pirateShips.remove(targetCell);
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        } else if (targetCell.getType() == Type.Treasure) {
                            treasuresCollected++;
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        }
                    } else {
                        break;
                    }


                }
            }
            isMissileClicked = false;

        } else {


            int replaceCol = shipCol + cols;

            if (replaceCol < mapSize) {

                BoardCell replaceCell = getReplaceCell(shipRow, replaceCol);

                if (replaceCell.getType() == Type.Blank) {

                    animateMove(shipCell, replaceCell, shipRow, shipCol, shipRow, replaceCol, false, false);
                } else if (replaceCell.getType() == Type.Treasure) {
                    treasuresCollected++;
                    animateMove(shipCell, replaceCell, shipRow, shipCol, shipRow, replaceCol, true, false);
                } else if (replaceCell.getType() == Type.Exit) {
                    animateMove(shipCell, replaceCell, shipRow, shipCol, shipRow, replaceCol, true, true);

                }
            }

        }
    }

    private static void setButtonsDisabled(boolean shouldDisable) {
        upButton.setDisable(shouldDisable);
        downButton.setDisable(shouldDisable);
        leftButton.setDisable(shouldDisable);
        rightButton.setDisable(shouldDisable);
        missileButton.setDisable(shouldDisable);
        boostButton.setDisable(shouldDisable);

    }

    private static void animateMove(BoardCell shipOrPirate, BoardCell replaceCell, int startRow, int startCol, int endRow, int endCol, boolean setBlank, boolean gameOver) {
        setButtonsDisabled(true);

        gameBoard.getChildren().remove(shipOrPirate);
        shipOrPirate.setVisible(false);
        gameBoard.add(shipOrPirate, endCol, endRow);
        gamePane.layout();


        gameBoard.getChildren().remove(shipOrPirate);
        gameBoard.add(shipOrPirate, startCol, startRow);
        shipOrPirate.setVisible(true);


        TranslateTransition translateTransition = new TranslateTransition();
        translateTransition.setDuration(Duration.seconds(0.5));

        translateTransition.setByX((endCol - startCol) * shipOrPirate.getSize());
        translateTransition.setByY((endRow - startRow) * shipOrPirate.getSize());

        translateTransition.setNode(shipOrPirate);
        translateTransition.play();


        translateTransition.setOnFinished(e -> {

            gameBoard.getChildren().remove(shipOrPirate);
            shipOrPirate.setTranslateX(0);
            shipOrPirate.setTranslateY(0);
            gameBoard.add(shipOrPirate, endCol, endRow);

            gameBoard.getChildren().remove(replaceCell);
            gameBoard.add(replaceCell, startCol, startRow);

            setButtonsDisabled(false);

            if (setBlank) {
                replaceCell.setType(Type.Blank);
                replaceCell.setStyle(mapSize);
            }

            if (gameOver) {
                if (shipOrPirate.getType() == Type.Pirate) {
                    showGameOver(false);

                } else {
                    showGameOver(true);
                }
            } else {
                if (shipOrPirate.getType() == Type.Ship)
                    movePirateShips();
            }


        });
    }


    private static void leftButtonClicked(int cols) {

        int shipRow = GridPane.getRowIndex(shipCell);
        int shipCol = GridPane.getColumnIndex(shipCell);

        boolean destroyed = false;
        if (isBoostClicked) {
            if (boostersRemaining >= 0) {

                int replaceCol1 = shipCol - 1;
                int replaceCol2 = shipCol - 2;
                int replaceCol3 = shipCol - 3;

                BoardCell replaceCell1 = getReplaceCell(shipRow, replaceCol1);
                BoardCell replaceCell2 = getReplaceCell(shipRow, replaceCol2);
                BoardCell replaceCell3 = getReplaceCell(shipRow, replaceCol3);

                if (replaceCell1 == null || replaceCell1.getType() == Type.Asteroid) {
                    isBoostClicked = false;
                    return;
                } else if (replaceCell2 == null || replaceCell2.getType() == Type.Asteroid) {
                    if (replaceCell1.getType() != Type.Pirate) {
                        isBoostClicked = false;
                        leftButtonClicked(1);
                    }
                    return;
                } else if (replaceCell3 == null || replaceCell3.getType() == Type.Asteroid) {
                    if (replaceCell1.getType() != Type.Pirate) {
                        isBoostClicked = false;
                        leftButtonClicked(1);
                    }
                    if (replaceCell2.getType() != Type.Pirate) {
                        leftButtonClicked(1);
                    }
                    return;
                } else if (replaceCell3.getType() == Type.Blank || replaceCell3.getType() == Type.Treasure) {
                    isBoostClicked = false;
                    leftButtonClicked(3);
                    return;
                }

            }

            isBoostClicked = false;
        } else if (isMissileClicked) {
            if (missilesRemaining >= 0) {
                int idx = 1;
                while (!destroyed) {
                    int targetCol = shipCol - idx;
                    idx++;

                    if (targetCol >= 0) {
                        BoardCell targetCell = getReplaceCell(shipRow, targetCol);

                        if (targetCell.getType() == Type.Asteroid) {
                            //asteroidsDestroyed++;
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        } else if (targetCell.getType() == Type.Pirate) {
                            //piratesDestroyed++;
                            pirateShips.remove(targetCell);
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        } else if (targetCell.getType() == Type.Treasure) {
                            treasuresCollected++;
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        }
                    } else {
                        break;
                    }


                }
            }
            isMissileClicked = false;

        } else {

            int replaceCol = shipCol - cols;

            if (replaceCol >= 0) {

                BoardCell replaceCell = getReplaceCell(shipRow, replaceCol);

                if (replaceCell.getType() == Type.Blank) {
                    animateMove(shipCell, replaceCell, shipRow, shipCol, shipRow, replaceCol, false, false);
                } else if (replaceCell.getType() == Type.Treasure) {
                    treasuresCollected++;
                    animateMove(shipCell, replaceCell, shipRow, shipCol, shipRow, replaceCol, true, false);
                } else if (replaceCell.getType() == Type.Exit) {
                    animateMove(shipCell, replaceCell, shipRow, shipCol, shipRow, replaceCol, true, true);

                }
            }
        }
    }

    private static void upButtonClicked(int rows) {

        int shipRow = GridPane.getRowIndex(shipCell);
        int shipCol = GridPane.getColumnIndex(shipCell);

        boolean destroyed = false;

        if (isBoostClicked) {
            if (boostersRemaining >= 0) {

                int replaceRow1 = shipRow - 1;
                int replaceRow2 = shipRow - 2;
                int replaceRow3 = shipRow - 3;

                BoardCell replaceCell1 = getReplaceCell(replaceRow1, shipCol);
                BoardCell replaceCell2 = getReplaceCell(replaceRow2, shipCol);
                BoardCell replaceCell3 = getReplaceCell(replaceRow3, shipCol);

                if (replaceCell1 == null || replaceCell1.getType() == Type.Asteroid) {
                    isBoostClicked = false;
                    return;
                } else if (replaceCell2 == null || replaceCell2.getType() == Type.Asteroid) {
                    if (replaceCell1.getType() != Type.Pirate) {
                        isBoostClicked = false;
                        upButtonClicked(1);
                    }
                    return;
                } else if (replaceCell3 == null || replaceCell3.getType() == Type.Asteroid) {
                    if (replaceCell1.getType() != Type.Pirate) {
                        isBoostClicked = false;
                        upButtonClicked(1);
                    }
                    if (replaceCell2.getType() != Type.Pirate) {
                        upButtonClicked(1);
                    }
                    return;
                } else if (replaceCell3.getType() == Type.Blank || replaceCell3.getType() == Type.Treasure) {
                    isBoostClicked = false;
                    upButtonClicked(3);
                    return;
                }

            }

            isBoostClicked = false;
        } else if (isMissileClicked) {
            if (missilesRemaining >= 0) {
                int idx = 1;
                while (!destroyed) {
                    int targetRow = shipRow - idx;
                    idx++;

                    if (targetRow >= 0) {
                        BoardCell targetCell = getReplaceCell(targetRow, shipCol);

                        if (targetCell.getType() == Type.Asteroid) {
                            //asteroidsDestroyed++;
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        } else if (targetCell.getType() == Type.Pirate) {
                            //piratesDestroyed++;
                            pirateShips.remove(targetCell);
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        } else if (targetCell.getType() == Type.Treasure) {
                            treasuresCollected++;
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        }
                    } else {
                        break;
                    }


                }
            }
            isMissileClicked = false;

        } else {
            int replaceRow = shipRow - rows;

            if (replaceRow >= 0) {

                BoardCell replaceCell = getReplaceCell(replaceRow, shipCol);

                if (replaceCell.getType() == Type.Blank) {
                    animateMove(shipCell, replaceCell, shipRow, shipCol, replaceRow, shipCol, false, false);
                } else if (replaceCell.getType() == Type.Treasure) {
                    treasuresCollected++;
                    animateMove(shipCell, replaceCell, shipRow, shipCol, replaceRow, shipCol, true, false);
                } else if (replaceCell.getType() == Type.Exit) {
                    animateMove(shipCell, replaceCell, shipRow, shipCol, replaceRow, shipCol, true, true);

                }
            }
        }
    }

    private static void downButtonClicked(int rows) {

        int shipRow = GridPane.getRowIndex(shipCell);
        int shipCol = GridPane.getColumnIndex(shipCell);

        boolean destroyed = false;

        if (isBoostClicked) {
            if (boostersRemaining >= 0) {

                int replaceRow1 = shipRow + 1;
                int replaceRow2 = shipRow + 2;
                int replaceRow3 = shipRow + 3;

                BoardCell replaceCell1 = getReplaceCell(replaceRow1, shipCol);
                BoardCell replaceCell2 = getReplaceCell(replaceRow2, shipCol);
                BoardCell replaceCell3 = getReplaceCell(replaceRow3, shipCol);

                if (replaceCell1 == null || replaceCell1.getType() == Type.Asteroid) {
                    isBoostClicked = false;
                    return;
                } else if (replaceCell2 == null || replaceCell2.getType() == Type.Asteroid) {
                    if (replaceCell1.getType() != Type.Pirate) {
                        isBoostClicked = false;
                        downButtonClicked(1);
                    }
                    return;
                } else if (replaceCell3 == null || replaceCell3.getType() == Type.Asteroid) {
                    if (replaceCell1.getType() != Type.Pirate) {
                        isBoostClicked = false;
                        downButtonClicked(1);
                    }
                    if (replaceCell2.getType() != Type.Pirate) {
                        downButtonClicked(1);
                    }
                    return;
                } else if (replaceCell3.getType() == Type.Blank || replaceCell3.getType() == Type.Treasure) {
                    isBoostClicked = false;
                    downButtonClicked(3);
                    return;
                }

            }

            isBoostClicked = false;
        } else if (isMissileClicked) {
            if (missilesRemaining >= 0) {
                int idx = 1;
                while (!destroyed) {
                    int targetRow = shipRow + idx;
                    idx++;

                    if (targetRow < mapSize) {
                        BoardCell targetCell = getReplaceCell(targetRow, shipCol);

                        if (targetCell.getType() == Type.Asteroid) {
                            //asteroidsDestroyed++;
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        } else if (targetCell.getType() == Type.Pirate) {
                            //piratesDestroyed++;
                            pirateShips.remove(targetCell);
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        } else if (targetCell.getType() == Type.Treasure) {
                            treasuresCollected++;
                            targetCell.setType(Type.Blank);
                            targetCell.setStyle(mapSize);
                            destroyed = true;
                        }
                    } else {
                        break;
                    }


                }
            }
            isMissileClicked = false;

        } else {

            int replaceRow = shipRow + rows;

            if (replaceRow < mapSize) {

                BoardCell replaceCell = getReplaceCell(replaceRow, shipCol);

                if (replaceCell.getType() == Type.Blank) {
                    animateMove(shipCell, replaceCell, shipRow, shipCol, replaceRow, shipCol, false, false);
                } else if (replaceCell.getType() == Type.Treasure) {
                    treasuresCollected++;
                    animateMove(shipCell, replaceCell, shipRow, shipCol, replaceRow, shipCol, true, false);
                } else if (replaceCell.getType() == Type.Exit) {
                    animateMove(shipCell, replaceCell, shipRow, shipCol, replaceRow, shipCol, true, true);

                }
            }
        }
    }


    public static GridPane createGameBoard() {
        GridPane gameBoard = new GridPane();
        gameBoard.setBorder(new Border(new BorderStroke(
                Color.WHITE,
                BorderStrokeStyle.SOLID,
                null,
                new BorderWidths(1)
        )));

        typesArray = new Type[mapSize][mapSize];

        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                typesArray[i][j] = Type.Blank;
            }
        }


        Random r = new Random();
        shipRowPos = r.nextInt(mapSize);
        shipColPos = r.nextInt(mapSize);
        typesArray[shipRowPos][shipColPos] = Type.Ship;

        setTypes(Type.Pirate, numOfPirates);
        setTypes(Type.Asteroid, numOfAsteroids);
        setTypes(Type.Treasure, numOfTreasures);

        while (true) {
            exitRowPos = r.nextInt(mapSize);
            exitColPos = r.nextInt(mapSize);

            if (typesArray[exitRowPos][exitColPos] == Type.Blank &&
                    hasClearPathFromShipToExit() && distance(shipRowPos, shipColPos, exitRowPos, exitColPos) >= 5 * 2) {
                typesArray[exitRowPos][exitColPos] = Type.Exit;
                break;
            }
        }

        for (int i = 0; i < mapSize; i++) {
            for (int j = 0; j < mapSize; j++) {
                BoardCell boardCell = new BoardCell(typesArray[i][j]);
                boardCell.setTextFill(Color.WHITE);
                boardCell.setStyle(mapSize);
                boardCell.setCursor(Cursor.HAND);

                if (typesArray[i][j] == Type.Ship) {
                    shipCell = boardCell;
                } else if (typesArray[i][j] == Type.Pirate) {
                    pirateShips.add(boardCell);
                } else if (typesArray[i][j] == Type.Exit) {
                    exitCell = boardCell;
                }

                gameBoard.add(boardCell, j, i);
            }
        }


        return gameBoard;
    }


    private static void setTypes(Type type, int count) {
        Random r = new Random();
        int placedCount = 0;
        while (placedCount < count) {
            int entityRowPos = r.nextInt(mapSize);
            int entityColPos = r.nextInt(mapSize);

            if (typesArray[entityRowPos][entityColPos] == Type.Blank) {
                if (type == Type.Pirate) {
                    if (distance(shipRowPos, shipColPos, entityRowPos, entityColPos) < 5 * 2) {
                        continue;
                    }
                }

                typesArray[entityRowPos][entityColPos] = type;
                placedCount++;
            }
        }
    }

    private static boolean hasClearPathFromShipToExit() {
        boolean[][] visited = new boolean[mapSize][mapSize];
        return checkPathToExitUsingDFS(shipRowPos, shipColPos, visited);
    }

    private static boolean checkPathToExitUsingDFS(int row, int col, boolean[][] visited) {

        if (row < 0 || row >= mapSize || col < 0 || col >= mapSize || visited[row][col]) {
            return false;
        }


        if (row == exitRowPos && col == exitColPos) {
            return true;
        }


        if (typesArray[row][col] == Type.Pirate || typesArray[row][col] == Type.Asteroid) {
            return false;
        }

        visited[row][col] = true;


        boolean pathFound = checkPathToExitUsingDFS(row - 1, col, visited) ||
                checkPathToExitUsingDFS(row + 1, col, visited) ||
                checkPathToExitUsingDFS(row, col - 1, visited) ||
                checkPathToExitUsingDFS(row, col + 1, visited);

        visited[row][col] = false;

        return pathFound;
    }


    private static int distance(int x1, int y1, int x2, int y2) {
        int distance = Math.abs(x1 - x2) + Math.abs(y1 - y2);
        return distance;
    }


    private static Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setCursor(Cursor.HAND);
        return button;
    }

    private static Label createStyledLabel(String text) {
        Label label = new Label(text);
        label.setTextFill(Color.WHITE);
        return label;
    }
}
