
public class Exercise233 {

}
