import java.util.Arrays;
import java.util.Collection;

public abstract class MyAbstractList<E> implements MyList<E> {
    // ...

    /** Adds the elements in otherList to this list.
     * Returns true if this list changed as a result of the call */
    public boolean addAll(MyList<E> otherList) {
        if (otherList == null || otherList.isEmpty()) {
            return false;
        }

        boolean modified = false;

        for (E item : otherList) {
            if (add(item)) {
                modified = true;
            }
        }

        return modified;
    }

    /** Removes all the elements in otherList from this list
     * Returns true if this list changed as a result of the call */
    public boolean removeAll(MyList<E> otherList) {
        if (otherList == null || otherList.isEmpty()) {
            return false;
        }

        boolean modified = false;

        for (E item : otherList) {
            if (remove(item)) {
                modified = true;
            }
        }

        return modified;
    }

    /** Retains the elements in this list that are also in otherList
     * Returns true if this list changed as a result of the call */
    public boolean retainAll(MyList<E> otherList) {
        if (otherList == null) {
            throw new NullPointerException("otherList cannot be null");
        }

        boolean modified = false;
        Object[] toRetain = otherList.toArray();

        for (int i = size() - 1; i >= 0; i--) {
            if (!Arrays.asList(toRetain).contains(get(i))) {
                remove(i);
                modified = true;
            }
        }

        return modified;
    }
    
}
