
public class Exercise245 {

}
