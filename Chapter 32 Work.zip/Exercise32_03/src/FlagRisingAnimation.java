import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;

public class FlagRisingAnimation extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create a pane
        Pane pane = new Pane();

        // Add an image view and add it to pane
        ImageView imageView = new ImageView("image/us.gif");
        pane.getChildren().add(imageView);

        // Create a scene and place it in the stage
        Scene scene = new Scene(pane, 250, 200);
        primaryStage.setTitle("FlagRisingAnimation");
        primaryStage.setScene(scene);

        // Create and start a flag raising thread
        FlagRaisingThread flagRaisingThread = new FlagRaisingThread(imageView);
        flagRaisingThread.start();

        primaryStage.show(); // Display the stage
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

    // Custom thread class for flag raising animation
    private class FlagRaisingThread extends Thread {
        private final ImageView imageView;

        FlagRaisingThread(ImageView imageView) {
            this.imageView = imageView;
        }

        @Override
        public void run() {
            try {
                for (int i = 0; i < 5; i++) {
                    Thread.sleep(2000); // Sleep for 2 seconds before raising the flag
                    imageView.setY(200); // Set initial position
                    Thread.sleep(500); // Sleep for 0.5 seconds
                    for (int j = 0; j < 100; j++) {
                        Thread.sleep(50); // Sleep for 0.05 seconds
                        imageView.setY(imageView.getY() - 2); // Raise the flag
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
