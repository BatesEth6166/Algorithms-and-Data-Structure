import java.io.*;
import java.net.*;
import java.util.Date;

public class Exercise33_01Server {
    public static void main(String[] args) {
        try {
            // Create a server socket
            ServerSocket serverSocket = new ServerSocket(8000);
            System.out.println("Server started at " + new Date());

            while (true) {
                // Listen for a connection request
                Socket socket = serverSocket.accept();

                // Create an input stream to receive data from the client
                ObjectInputStream inputFromClient = new ObjectInputStream(socket.getInputStream());

                // Receive loan information from the client
                Loan loan = (Loan) inputFromClient.readObject();

                // Compute monthly payment and total payment
                double monthlyPayment = loan.getMonthlyPayment();
                double totalPayment = loan.getTotalPayment();

                // Create an output stream to send data to the client
                ObjectOutputStream outputToClient = new ObjectOutputStream(socket.getOutputStream());

                // Send monthly payment and total payment back to the client
                outputToClient.writeObject(monthlyPayment);
                outputToClient.writeObject(totalPayment);

                // Close the socket
                socket.close();
            }
        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
}
