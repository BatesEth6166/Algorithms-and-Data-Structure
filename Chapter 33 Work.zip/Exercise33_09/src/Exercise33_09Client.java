
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;

public class Exercise33_09Client extends Application {
    private TextArea taServer = new TextArea();
    private TextArea taClient = new TextArea();
    private DataOutputStream toServer;
    private DataInputStream fromServer;

    @Override
    public void start(Stage primaryStage) {
        taServer.setWrapText(true);
        taClient.setWrapText(true);

        BorderPane pane1 = new BorderPane();
        pane1.setTop(new Label("Server History"));
        pane1.setCenter(new ScrollPane(taServer));
        BorderPane pane2 = new BorderPane();
        pane2.setTop(new Label("New Message"));
        pane2.setCenter(new ScrollPane(taClient));

        VBox vBox = new VBox(5);
        vBox.getChildren().addAll(pane1, pane2);

        Scene scene = new Scene(vBox, 400, 300);
        primaryStage.setTitle("Exercise33_09Client");
        primaryStage.setScene(scene);
        primaryStage.show();

        try {
            Socket socket = new Socket("localhost", 8000);

            fromServer = new DataInputStream(socket.getInputStream());
            toServer = new DataOutputStream(socket.getOutputStream());

            taClient.setOnKeyPressed(e -> {
                if (e.getCode().equals(javafx.scene.input.KeyCode.ENTER)) {
                    try {
                        String message = taClient.getText().trim();
                        toServer.writeUTF(message);
                        appendMessage("Client: " + message);
                        taClient.clear();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            });

            new Thread(() -> {
                while (true) {
                    try {
                        String message = fromServer.readUTF();
                        appendMessage("Server: " + message);

                        // Handle the message received from the server
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }).start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void appendMessage(String message) {
        taServer.appendText(message + "\n");
    }

    public static void main(String[] args) {
        launch(args);
    }
}