import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class Exercise33_09Server extends Application {
    private TextArea taServer = new TextArea();
    private TextArea taClient = new TextArea();
    private DataOutputStream toClient;
    private DataInputStream fromClient;

    @Override
    public void start(Stage primaryStage) {
        taServer.setWrapText(true);
        taClient.setWrapText(true);

        BorderPane pane1 = new BorderPane();
        pane1.setTop(new Label("Server History"));
        pane1.setCenter(new ScrollPane(taServer));
        BorderPane pane2 = new BorderPane();
        pane2.setTop(new Label("New Message"));
        pane2.setCenter(new ScrollPane(taClient));

        VBox vBox = new VBox(5);
        vBox.getChildren().addAll(pane1, pane2);

        Scene scene = new Scene(vBox, 400, 300);
        primaryStage.setTitle("Exercise33_09Server");
        primaryStage.setScene(scene);
        primaryStage.show();

        new Thread(() -> {
            try {
                ServerSocket serverSocket = new ServerSocket(8000);
                Socket socket = serverSocket.accept();

                fromClient = new DataInputStream(socket.getInputStream());
                toClient = new DataOutputStream(socket.getOutputStream());

                while (true) {
                    String message = fromClient.readUTF();
                    appendMessage("Client: " + message);

                    // Handle the message received from the client
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }).start();
    }

    public void appendMessage(String message) {
        taServer.appendText(message + "\n");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
