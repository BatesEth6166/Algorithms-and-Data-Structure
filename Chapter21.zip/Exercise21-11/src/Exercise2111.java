import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Exercise2111 extends Application {
    private Map<String, Integer>[] mapForBoy = new HashMap[10];
    private Map<String, Integer>[] mapForGirl = new HashMap[10];
    private Button btFindRanking = new Button("Find Ranking");
    private ComboBox<Integer> cboYear = new ComboBox<>();
    private ComboBox<String> cboGender = new ComboBox<>();
    private TextField tfName = new TextField();
    private Label lblResult = new Label();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        initializeData();

        GridPane gridPane = new GridPane();
        gridPane.add(new Label("Select a year:"), 0, 0);
        gridPane.add(new Label("Boy or girl?"), 0, 1);
        gridPane.add(new Label("Enter a name:"), 0, 2);
        gridPane.add(cboYear, 1, 0);
        gridPane.add(cboGender, 1, 1);
        gridPane.add(tfName, 1, 2);
        gridPane.add(btFindRanking, 1, 3);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(5);
        gridPane.setVgap(5);

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(gridPane);
        borderPane.setBottom(lblResult);
        BorderPane.setAlignment(lblResult, Pos.CENTER);

        // Create a scene and place it in the stage
        Scene scene = new Scene(borderPane, 370, 160);
        primaryStage.setTitle("Exercise21_11"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage

        for (int year = 2001; year <= 2010; year++) {
            cboYear.getItems().add(year);
        }
        cboYear.setValue(2001);
        cboGender.getItems().addAll("Male", "Female");
        cboGender.setValue("Male");

        btFindRanking.setOnAction(e -> findRanking());
    }

    // Initialize the data from the provided URLs
    private void initializeData() {
        for (int i = 0; i < 10; i++) {
            mapForBoy[i] = new HashMap<>();
            mapForGirl[i] = new HashMap<>();
        }

        for (int year = 2001; year <= 2010; year++) {
            try {
                URL url = new URL("http://liveexample.pearsoncmg.com/data/babynamesranking" + year + ".txt");
                Scanner input = new Scanner(url.openStream());

                while (input.hasNext()) {
                    int ranking = input.nextInt();
                    String boyName = input.next();
                    input.nextInt(); // Skip the number of boy names
                    String girlName = input.next();
                    input.nextInt(); // Skip the number of girl names

                    mapForBoy[year - 2001].put(boyName, ranking);
                    mapForGirl[year - 2001].put(girlName, ranking);
                }

                input.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Find and display the ranking for the entered name, year, and gender
    private void findRanking() {
        int selectedYear = cboYear.getValue();
        String selectedGender = cboGender.getValue();
        String selectedName = tfName.getText();

        Map<String, Integer>[] selectedMap = (selectedGender.equals("Male")) ? mapForBoy : mapForGirl;

        if (selectedYear >= 2001 && selectedYear <= 2010) {
            Integer ranking = selectedMap[selectedYear - 2001].get(selectedName);
            if (ranking != null) {
                lblResult.setText(selectedName + " is ranked #" + ranking + " in " + selectedYear);
            } else {
                lblResult.setText("Name not found in the selected year and gender.");
            }
        } else {
            lblResult.setText("Please select a year between 2001 and 2010.");
        }
    }
}
