import java.util.*;

public class Exercise217 {
    public static void main(String[] args) {
        // Set text in a string
        String text = "Good morning. Have a good class. " +
                "Have a good visit. Have fun!";
        
        // Create a HashMap to hold words as keys and counts as values
        Map<String, Integer> map = new HashMap<>();
        
        // Split the text into words and count occurrences
        String[] words = text.split("[\\s+\\p{P}]");
        for (String word : words) {
            String key = word.toLowerCase();
            if (!key.isEmpty()) {
                map.put(key, map.getOrDefault(key, 0) + 1);
            }
        }
        
        // Create a list of WordOccurrence objects and sort it by counts
        List<WordOccurrence> wordList = new ArrayList<>();
        map.forEach((k, v) -> wordList.add(new WordOccurrence(k, v)));
        Collections.sort(wordList);
        
        // Display words in ascending order of occurrence counts
        for (WordOccurrence word : wordList) {
            System.out.println(word.getWord() + "\t" + word.getCount());
        }
    }
}

class WordOccurrence implements Comparable<WordOccurrence> {
    private String word;
    private int count;

    public WordOccurrence(String word, int count) {
        this.word = word;
        this.count = count;
    }

    public String getWord() {
        return word;
    }

    public int getCount() {
        return count;
    }

    @Override
    public int compareTo(WordOccurrence other) {
        return Integer.compare(this.count, other.count);
    }
}
